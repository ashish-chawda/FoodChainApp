import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Products } from '../products';

@Component({
  selector: 'app-foodchain-home',
  templateUrl: './foodchain-home.component.html',
  styleUrls: ['./foodchain-home.component.css']
})
export class FoodchainHomeComponent implements OnInit {

  userName: string;
  cartItems: number;
  cart: Products[];
  constructor(private router: Router) { 

    this.userName = sessionStorage.getItem('loggedUser');    
    this.cartItems = 0;
    this.cart = [];
    sessionStorage.setItem('loggedUserCartItems', JSON.stringify(this.cartItems));
    sessionStorage.setItem('loggedUserCart', JSON.stringify(this.cart));
    
  }

  ngOnInit() {
  }

  selectProduct(productName){
    console.log(productName)
    if(productName === 'pizzas'){
      
      this.router.navigate(['pizzas'])
    }
    else if(productName === 'sandwitches'){
      
      this.router.navigate(['sandwitches'])
    }
    else if(productName === 'drinks'){
      
      this.router.navigate(['drinks'])
    }
  }
}
