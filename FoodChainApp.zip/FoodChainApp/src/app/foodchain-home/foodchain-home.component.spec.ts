import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FoodchainHomeComponent } from './foodchain-home.component';

describe('FoodchainHomeComponent', () => {
  let component: FoodchainHomeComponent;
  let fixture: ComponentFixture<FoodchainHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FoodchainHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FoodchainHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
