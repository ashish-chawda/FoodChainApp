export interface Orders{
    OrderOwner: string,
    OrderDate: Date,
    OrderStatus: string,
    OrderAmount: number
}