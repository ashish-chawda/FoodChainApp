import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'FoodChainApp';
  isUserLoggedIn: boolean;
  nameOfUser: string;
  constructor(){
    this.nameOfUser = '';
    this.isUserLoggedIn = false;
  }


  getLoginStatus(messageFromChild){   
    this.isUserLoggedIn = messageFromChild.isUserLoggedIn;
    this.nameOfUser = messageFromChild.nameOfUser;
  }
}
