import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { FoodChainService } from '../api/food-chain.service';
import { FormControl, Validators } from '@angular/forms';
import { Products } from '../products';
import { UserCart } from '../user-cart';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {

  @Output() userLoginStatus = new EventEmitter<{isUserLoggedIn: boolean, nameOfUser: string}>();
  isUserValid: boolean;
  authenticationErrorMessage: string;
  loginName: FormControl;
  loginPasswd: FormControl;
  cart: UserCart[];
  constructor(private foodChainService: FoodChainService) {
    this.isUserValid = false;
    this.authenticationErrorMessage = '';
    this.loginName = new FormControl('', [Validators.required]);
    this.loginPasswd = new FormControl('', [Validators.required]);  
    this.cart = [];  
   }

  ngOnInit() {
  }

  async checkUser(username, password){
    this.authenticationErrorMessage = '';
    this.foodChainService.checkIfUserExists(username, password).subscribe(data => {
      this.isUserValid = data;
      if(this.isUserValid){
        sessionStorage.setItem('loggedUser', username);
        sessionStorage.setItem('loggedUserCart', JSON.stringify(this.cart));
        this.userLoginStatus.emit({isUserLoggedIn: this.isUserValid, nameOfUser: username});
      }else {
        this.isUserValid = false;
        this.loginPasswd.reset();
        this.loginName.reset();
        this.authenticationErrorMessage = 'Username or Password entered is incorrect !';
        
      }
    });
    
  }

} 
