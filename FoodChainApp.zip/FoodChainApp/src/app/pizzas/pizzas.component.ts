import { Component, OnInit } from '@angular/core';
import { FoodChainService } from '../api/food-chain.service';
import { Products } from '../products';
import { MatSnackBar, MatDialog } from '@angular/material';
import { UserCart } from '../user-cart';


@Component({
  selector: 'app-pizzas',
  templateUrl: './pizzas.component.html',
  styleUrls: ['./pizzas.component.css']
})
export class PizzasComponent implements OnInit {

  products: Products[];
  pizzaCrust: Products[];
  pizzaToppings: Products[];
  pizzaSauce: Products[];
  cart: UserCart[];
  cartItems: number;
  isAddonSelection: boolean;
  selectedCrust: string;
  selectedToppings: string;
  selectedSauce: string;
  constructor(private foodChainService: FoodChainService, private _snackBar: MatSnackBar, public dialog: MatDialog) {
    this.products = [];
    this.pizzaCrust = [];
    this.pizzaToppings = [];
    this.pizzaSauce = [];
    this.cartItems = 0;
    this.isAddonSelection = false;
    this.selectedCrust = '';
    this.selectedToppings = '';
    this.selectedSauce = '';
  }

  selectCrust(product){

    this.selectedCrust = product.ProductName;
    this.addAddonToCart(product); 
    this.isAddonSelection = false;
  }

  addAddonToCart(product){
    this.cart = JSON.parse(sessionStorage.getItem('loggedUserCart'));
    this.cartItems = JSON.parse(sessionStorage.getItem('loggedUserCartItems'));    
    if(this.selectedCrust == ''){      
      this.addToCart(product, 1);
    }
    else
    {
     this.cart = this.cart.splice((this.cart.length - 1), 1);    
     this.cartItems = this.cartItems - 1;
     sessionStorage.setItem('loggedUserCartItems', JSON.stringify(this.cartItems));
     sessionStorage.setItem('loggedUserCart', JSON.stringify(this.cart));
     this.addToCart(product, 1);
    }   
    
    
    var element = document.getElementById("btnCrust-" + product.ProductName);
    var buttons = document.querySelectorAll('[id^="btnCrust-"]');
    var noOfButtons = document.querySelectorAll('[id^="btnCrust-"]').length;

    for (let index = 0; index < noOfButtons; index++) {
      buttons[index].classList.remove('btn-success');
      buttons[index].classList.add('btn-warning');
      buttons[index].innerHTML = 'Select';
    }

    element.innerHTML = element.innerHTML == 'Select' ? 'Selected' : 'Select';
    if (element.classList.contains('btn-warning') && element.innerHTML == 'Selected') {
      element.classList.remove('btn-warning');
      element.classList.add('btn-success');
     
    }
    else {
      element.classList.remove('btn-success');
      element.classList.add('btn-warning');
      
    } 
  }

  selectToppings(product){
    
      this.selectToppings = product.ProductName;
      this.addAddonToCart(product);
      this.isAddonSelection = false;
   
  }

  selectSauce(product){
    
      this.selectSauce = product.ProductName;
      this.addAddonToCart(product);
      this.isAddonSelection = false;
    
  }


  ngOnInit() {
    this.getPizzas();
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 3000,
    });
  }

  async getPizzas() {
    this.products = await this.foodChainService.getProductsViaType('pizza').toPromise().then(data => {
      return data;
    });
  }

  async getAddons(){
    this.pizzaCrust = await this.foodChainService.getProductsViaType('crust').toPromise().then(data => {
      return data;
    });
    this.pizzaToppings = await this.foodChainService.getProductsViaType('toppings').toPromise().then(data => {
      return data;
    });
    this.pizzaSauce = await this.foodChainService.getProductsViaType('sauce').toPromise().then(data => {
      return data;
    });
  }

  addPizza(product, quantity){

    this.addToCart(product, quantity);
    this.getAddons();
    this.isAddonSelection = true;
  }

  addToCart(product, quantity) {
    let itemFound: boolean = false;
    this.cart = JSON.parse(sessionStorage.getItem('loggedUserCart'));
    this.cartItems = JSON.parse(sessionStorage.getItem('loggedUserCartItems'));
    if (this.cart.length > 0) {
      for (let index = 0; index < this.cart.length; index++) {
        const element = this.cart[index].ProductId;
        if (product.ProductId == element) {
          itemFound = true;
          this.cart[index].ProductQuantity = quantity;
          this.cart[index].ProductPrice = quantity * product.ProductPrice;
          break;
        }
      }

      if (!itemFound) {
        this.cart.push({ ProductId: product.ProductId, ProductName: product.ProductName, ProductQuantity: quantity, ProductPrice: (product.ProductPrice * quantity), ProductDiscount: product.ProductDiscountPercentage });
        this.cartItems = this.cartItems + 1;
      }


    }
    else {
      this.cart.push({ ProductId: product.ProductId, ProductName: product.ProductName, ProductQuantity: quantity, ProductPrice: (product.ProductPrice * quantity), ProductDiscount: product.ProductDiscountPercentage });
      this.cartItems = this.cartItems + 1;
    }

    sessionStorage.setItem('loggedUserCart', JSON.stringify(this.cart));
    sessionStorage.setItem('loggedUserCartItems', JSON.stringify(this.cartItems));
    this.openSnackBar(product.ProductName + ' added to cart !', 'Quantity: ' + quantity);
   
  }

}


