export interface UserCart{
    ProductId: number,
    ProductName: string,
    ProductQuantity: number,
    ProductPrice: number,
    ProductDiscount: number
}