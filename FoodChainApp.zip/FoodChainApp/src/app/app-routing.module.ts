import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FoodchainHomeComponent } from './foodchain-home/foodchain-home.component';
import { PizzasComponent } from './pizzas/pizzas.component';
import { SandwitchesComponent } from './sandwitches/sandwitches.component';
import { DrinksComponent } from './drinks/drinks.component';
import { CartComponent } from './cart/cart.component';


const routes: Routes = [
  {path:'', component: FoodchainHomeComponent},
  {path:'home', component: FoodchainHomeComponent},
  {path:'pizzas', component: PizzasComponent},
  {path:'sandwitches', component: SandwitchesComponent},
  {path:'drinks', component: DrinksComponent},
  {path:'cart', component: CartComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
