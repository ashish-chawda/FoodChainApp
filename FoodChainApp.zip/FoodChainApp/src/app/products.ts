export interface Products{
    ProductId: number,
    ProductName: string,
    ProductType: string,
    ProductStock: number,
    ProductPrice: number,
    ProductDiscountPercentage: number
}