import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs/internal/Observable';
import { Products } from '../products';
import { Orders } from '../orders';


@Injectable({
  providedIn: 'root'
})
export class FoodChainService {

  public API = "http://localhost:65371/api";
  public USERS_API = `${this.API}/users`;
  public ROLES_API = `${this.API}/roles`;
  public PRODUCTS_API = `${this.API}/products`;
  public ORDERS_API = `${this.API}/FoodChainOrders`;


  constructor(private httpClient: HttpClient) { }

  checkIfUserExists(username, passwd): Observable<boolean> {
    return this.httpClient.get<boolean>(`${this.USERS_API}?userName=${username}&pass=${passwd}`);
  }


  getProductsViaType(type): Observable<Products[]>{
    return this.httpClient.get<Products[]>(`${this.PRODUCTS_API}/GetProductViaType?productType=${type}`);
  }

  saveOrder(order: Orders): Observable<Orders>{
    return this.httpClient.post<Orders>(`${this.ORDERS_API}`, order);
  }



}
