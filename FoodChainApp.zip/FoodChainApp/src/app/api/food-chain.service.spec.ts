import { TestBed } from '@angular/core/testing';

import { FoodChainService } from './food-chain.service';

describe('FoodChainService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FoodChainService = TestBed.get(FoodChainService);
    expect(service).toBeTruthy();
  });
});
