import { Component, OnInit } from '@angular/core';
import { Products } from '../products';
import { UserCart } from '../user-cart';
import { FoodChainService } from '../api/food-chain.service';
import { Orders } from '../orders';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  //itemsAddedToCart: UserCart[];
  isOrderPlaced: boolean;
  displayedColumns: string[] = ['Item Name', 'Item Quantity', 'Item Price', 'Item Discount'];
  dataSource = JSON.parse(sessionStorage.getItem('loggedUserCart'));
  constructor(private foodChainService: FoodChainService) {   
    this.isOrderPlaced = false;
  //this.itemsAddedToCart = JSON.parse(sessionStorage.getItem('loggedUserCart'));  
  
  }

  getTotalCost() {
    return this.dataSource.map(t => t.ProductPrice).reduce((acc, value) => acc + value, 0);
  }

  getDiscountPrice(){
    let totalDiscountPrice: number = 0;
    for (let index = 0; index < this.dataSource.length; index++) {
      const element = this.dataSource[index].ProductPrice / this.dataSource[index].ProductDiscount;
      totalDiscountPrice = totalDiscountPrice + element;      
    }

    return totalDiscountPrice;
  }

  saveOrder(){
    let order: Orders = {OrderOwner: sessionStorage.getItem('loggedUser'), OrderDate: new Date(), OrderAmount: (this.getTotalCost() - this.getDiscountPrice()), OrderStatus: 'Processing'};
    this.foodChainService.saveOrder(order).subscribe(data => {
      this.isOrderPlaced = true;
      sessionStorage.setItem('loggedUserCartItems', JSON.stringify(0));
    })

  }
  ngOnInit() {
   
  }

}
