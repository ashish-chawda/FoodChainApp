import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-navbar',
  templateUrl: './app-navbar.component.html',
  styleUrls: ['./app-navbar.component.css']
})
export class AppNavbarComponent implements OnInit {

  cartItems: number;
  constructor() { 
  }

  get cartItemsValue(): any{
    return JSON.parse(sessionStorage.getItem('loggedUserCartItems'));
  }
  ngOnInit() {
    sessionStorage.setItem('loggedUserCartItems', JSON.stringify(0));
    this.cartItems = JSON.parse(sessionStorage.getItem('loggedUserCartItems'));
  }

  logout(){
    console.log("inside logout");
    sessionStorage.clear();
    window.location.replace('/');       
  }

}
