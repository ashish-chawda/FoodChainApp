import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SandwitchesComponent } from './sandwitches.component';

describe('SandwitchesComponent', () => {
  let component: SandwitchesComponent;
  let fixture: ComponentFixture<SandwitchesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SandwitchesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SandwitchesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
