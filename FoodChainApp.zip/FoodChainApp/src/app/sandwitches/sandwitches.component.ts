import { Component, OnInit } from '@angular/core';
import { FoodChainService } from '../api/food-chain.service';
import { Products } from '../products';
import { UserCart } from '../user-cart';
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-sandwitches',
  templateUrl: './sandwitches.component.html',
  styleUrls: ['./sandwitches.component.css']
})
export class SandwitchesComponent implements OnInit {

  products: Products[];
  cart: UserCart[];
  cartItems: number;
  constructor(private foodChainService: FoodChainService, private _snackBar: MatSnackBar) { 
    this.products = [];
    this.cartItems = 0;
  }

  ngOnInit() {
    this.getSandwitches();
  }
  
  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 3000,
    });
  }

  async getSandwitches(){
    this.products = await this.foodChainService.getProductsViaType('sandwitch').toPromise().then(data => {
      return data;
    });
  }

  addToCart(product, quantity) {
    let itemFound: boolean = false;
    this.cart = JSON.parse(sessionStorage.getItem('loggedUserCart'));
    this.cartItems = JSON.parse(sessionStorage.getItem('loggedUserCartItems'));
    if (this.cart.length > 0) {
      for (let index = 0; index < this.cart.length; index++) {
        const element = this.cart[index].ProductId;
        if (product.ProductId == element) {
          itemFound = true;
          this.cart[index].ProductQuantity = quantity;
          this.cart[index].ProductPrice = quantity * product.ProductPrice;
          break;
        }
      }

      if (!itemFound) {
        this.cart.push({ ProductId: product.ProductId, ProductName: product.ProductName, ProductQuantity: quantity, ProductPrice: (product.ProductPrice * quantity), ProductDiscount: product.ProductDiscountPercentage });
        this.cartItems = this.cartItems + 1;
      }


    }
    else {
      this.cart.push({ ProductId: product.ProductId, ProductName: product.ProductName, ProductQuantity: quantity, ProductPrice: (product.ProductPrice * quantity), ProductDiscount: product.ProductDiscountPercentage });
      this.cartItems = this.cartItems + 1;
    }

    sessionStorage.setItem('loggedUserCart', JSON.stringify(this.cart));
    sessionStorage.setItem('loggedUserCartItems', JSON.stringify(this.cartItems));
    this.openSnackBar(product.ProductName + ' added to cart !', 'Quantity: ' + quantity);

  }

}
