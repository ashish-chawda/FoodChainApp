﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using FoodChainWebApi;

namespace FoodChainWebApi.Controllers
{
    public class FoodChainOrdersController : ApiController
    {
        private FoodChainEntities db = new FoodChainEntities();

        // GET: api/FoodChainOrders
        public IQueryable<FoodChain_Orders> GetFoodChain_Orders()
        {
            return db.FoodChain_Orders;
        }

        // GET: api/FoodChainOrders/5
        [ResponseType(typeof(FoodChain_Orders))]
        public async Task<IHttpActionResult> GetFoodChain_Orders(int id)
        {
            FoodChain_Orders foodChain_Orders = await db.FoodChain_Orders.FindAsync(id);
            if (foodChain_Orders == null)
            {
                return NotFound();
            }

            return Ok(foodChain_Orders);
        }

        // PUT: api/FoodChainOrders/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutFoodChain_Orders(int id, FoodChain_Orders foodChain_Orders)
        {
           

            if (id != foodChain_Orders.OrderId)
            {
                return BadRequest();
            }

            db.Entry(foodChain_Orders).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!FoodChain_OrdersExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/FoodChainOrders
        [ResponseType(typeof(FoodChain_Orders))]
        public async Task<IHttpActionResult> PostFoodChain_Orders(FoodChain_Orders foodChain_Orders)
        {
            
            db.FoodChain_Orders.Add(foodChain_Orders);
            await db.SaveChangesAsync();

            return CreatedAtRoute("DefaultApi", new { id = foodChain_Orders.OrderId }, foodChain_Orders);
        }

        // DELETE: api/FoodChainOrders/5
        [ResponseType(typeof(FoodChain_Orders))]
        public async Task<IHttpActionResult> DeleteFoodChain_Orders(int id)
        {
            FoodChain_Orders foodChain_Orders = await db.FoodChain_Orders.FindAsync(id);
            if (foodChain_Orders == null)
            {
                return NotFound();
            }

            db.FoodChain_Orders.Remove(foodChain_Orders);
            await db.SaveChangesAsync();

            return Ok(foodChain_Orders);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool FoodChain_OrdersExists(int id)
        {
            return db.FoodChain_Orders.Count(e => e.OrderId == id) > 0;
        }
    }
}