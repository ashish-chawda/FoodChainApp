﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using FoodChainWebApi;

namespace FoodChainWebApi.Controllers
{
    public class UsersController : ApiController
    {
        private FoodChainEntities db = new FoodChainEntities();

        // GET: api/Users
        public IQueryable<FoodChainUsers> GetFoodChainUsers()
        {
            return db.FoodChainUsers;
        }

        [ResponseType(typeof(Boolean))]
        public Boolean GetFoodChainUsers(string userName, string pass)
        {
            int count = (from x in db.FoodChainUsers where x.UserName == userName && x.Password == pass select x).Count();
            return count > 0 ? true : false;
        }



        // GET: api/Users/5
        [ResponseType(typeof(FoodChainUsers))]
        public async Task<IHttpActionResult> GetFoodChainUsers(int id)
        {
            FoodChainUsers foodChainUsers = await db.FoodChainUsers.FindAsync(id);
            if (foodChainUsers == null)
            {
                return NotFound();
            }

            return Ok(foodChainUsers);
        }

        // PUT: api/Users/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutFoodChainUsers(int id, FoodChainUsers foodChainUsers)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != foodChainUsers.UserId)
            {
                return BadRequest();
            }

            db.Entry(foodChainUsers).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!FoodChainUsersExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Users
        [ResponseType(typeof(FoodChainUsers))]
        public async Task<IHttpActionResult> PostFoodChainUsers(FoodChainUsers foodChainUsers)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.FoodChainUsers.Add(foodChainUsers);
            await db.SaveChangesAsync();

            return CreatedAtRoute("DefaultApi", new { id = foodChainUsers.UserId }, foodChainUsers);
        }

        // DELETE: api/Users/5
        [ResponseType(typeof(FoodChainUsers))]
        public async Task<IHttpActionResult> DeleteFoodChainUsers(int id)
        {
            FoodChainUsers foodChainUsers = await db.FoodChainUsers.FindAsync(id);
            if (foodChainUsers == null)
            {
                return NotFound();
            }

            db.FoodChainUsers.Remove(foodChainUsers);
            await db.SaveChangesAsync();

            return Ok(foodChainUsers);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool FoodChainUsersExists(int id)
        {
            return db.FoodChainUsers.Count(e => e.UserId == id) > 0;
        }
    }
}