﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using FoodChainWebApi;

namespace FoodChainWebApi.Controllers
{
    public class RolesController : ApiController
    {
        private FoodChainEntities db = new FoodChainEntities();

        // GET: api/Roles
        public IQueryable<FoodChainRoles> GetFoodChainRoles()
        {
            return db.FoodChainRoles;
        }

        // GET: api/Roles/5
        [ResponseType(typeof(FoodChainRoles))]
        public async Task<IHttpActionResult> GetFoodChainRoles(int id)
        {
            FoodChainRoles foodChainRoles = await db.FoodChainRoles.FindAsync(id);
            if (foodChainRoles == null)
            {
                return NotFound();
            }

            return Ok(foodChainRoles);
        }

        // PUT: api/Roles/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutFoodChainRoles(int id, FoodChainRoles foodChainRoles)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != foodChainRoles.RoleId)
            {
                return BadRequest();
            }

            db.Entry(foodChainRoles).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!FoodChainRolesExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Roles
        [ResponseType(typeof(FoodChainRoles))]
        public async Task<IHttpActionResult> PostFoodChainRoles(FoodChainRoles foodChainRoles)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.FoodChainRoles.Add(foodChainRoles);
            await db.SaveChangesAsync();

            return CreatedAtRoute("DefaultApi", new { id = foodChainRoles.RoleId }, foodChainRoles);
        }

        // DELETE: api/Roles/5
        [ResponseType(typeof(FoodChainRoles))]
        public async Task<IHttpActionResult> DeleteFoodChainRoles(int id)
        {
            FoodChainRoles foodChainRoles = await db.FoodChainRoles.FindAsync(id);
            if (foodChainRoles == null)
            {
                return NotFound();
            }

            db.FoodChainRoles.Remove(foodChainRoles);
            await db.SaveChangesAsync();

            return Ok(foodChainRoles);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool FoodChainRolesExists(int id)
        {
            return db.FoodChainRoles.Count(e => e.RoleId == id) > 0;
        }
    }
}