﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using FoodChainWebApi;

namespace FoodChainWebApi.Controllers
{
    public class ProductsController : ApiController
    {
        private FoodChainEntities db = new FoodChainEntities();

        // GET: api/Products
        public IQueryable<FoodChainProducts> GetFoodChainProducts()
        {
            return db.FoodChainProducts;
        }


        public IQueryable<FoodChainProducts> GetProductViaType(string productType)
        {
            var result = from x in db.FoodChainProducts where x.ProductType == productType select x;
            return result;
        }


        // GET: api/Products/5
        [ResponseType(typeof(FoodChainProducts))]
        public async Task<IHttpActionResult> GetFoodChainProducts(int id)
        {
            FoodChainProducts foodChainProducts = await db.FoodChainProducts.FindAsync(id);
            if (foodChainProducts == null)
            {
                return NotFound();
            }

            return Ok(foodChainProducts);
        }

        // PUT: api/Products/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutFoodChainProducts(int id, FoodChainProducts foodChainProducts)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != foodChainProducts.ProductId)
            {
                return BadRequest();
            }

            db.Entry(foodChainProducts).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!FoodChainProductsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Products
        [ResponseType(typeof(FoodChainProducts))]
        public async Task<IHttpActionResult> PostFoodChainProducts(FoodChainProducts foodChainProducts)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.FoodChainProducts.Add(foodChainProducts);
            await db.SaveChangesAsync();

            return CreatedAtRoute("DefaultApi", new { id = foodChainProducts.ProductId }, foodChainProducts);
        }

        // DELETE: api/Products/5
        [ResponseType(typeof(FoodChainProducts))]
        public async Task<IHttpActionResult> DeleteFoodChainProducts(int id)
        {
            FoodChainProducts foodChainProducts = await db.FoodChainProducts.FindAsync(id);
            if (foodChainProducts == null)
            {
                return NotFound();
            }

            db.FoodChainProducts.Remove(foodChainProducts);
            await db.SaveChangesAsync();

            return Ok(foodChainProducts);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool FoodChainProductsExists(int id)
        {
            return db.FoodChainProducts.Count(e => e.ProductId == id) > 0;
        }
    }
}